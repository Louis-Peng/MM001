sap.ui.define([
	"ns/BSP11/test/unit/controller/POINF.controller"
], function () {
	"use strict";
});
